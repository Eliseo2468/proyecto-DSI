/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.boncortproyect.logica;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Tickets")
public class Tickets implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id_tickets")
    private int id_tickets;
    @Column(name = "Num_vinieta")
    private String Num_vinieta;
    @Column(name = "Contenido")
    private String Contenido;
    @Column(name = "peso_paquete")
    private float peso_paquete;
    @Column(name = "precio_paquete")
    private float precio_paquete;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_cliente_Re")
    Cliente clienteRe;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_cliente_En")
    Cliente clienteEn;
    
    public Tickets() {
    }

    public Tickets(int id_tickets, String Num_vinieta, String Contenido, float peso_paquete, float precio_paquete, Cliente clienteRe, Cliente clienteEn) {
        this.id_tickets = id_tickets;
        this.Num_vinieta = Num_vinieta;
        this.Contenido = Contenido;
        this.peso_paquete = peso_paquete;
        this.precio_paquete = precio_paquete;
        this.clienteRe = clienteRe;
        this.clienteEn = clienteEn;
    }

    public int getId_tickets() {
        return id_tickets;
    }

    public void setId_tickets(int id_tickets) {
        this.id_tickets = id_tickets;
    }

    public String getNum_vinieta() {
        return Num_vinieta;
    }

    public void setNum_vinieta(String Num_vinieta) {
        this.Num_vinieta = Num_vinieta;
    }

    public String getContenido() {
        return Contenido;
    }

    public void setContenido(String Contenido) {
        this.Contenido = Contenido;
    }

    public float getPeso_paquete() {
        return peso_paquete;
    }

    public void setPeso_paquete(float peso_paquete) {
        this.peso_paquete = peso_paquete;
    }

    public float getPrecio_paquete() {
        return precio_paquete;
    }

    public void setPrecio_paquete(float precio_paquete) {
        this.precio_paquete = precio_paquete;
    }

    public Cliente getClienteRe() {
        return clienteRe;
    }

    public void setClienteRe(Cliente clienteRe) {
        this.clienteRe = clienteRe;
    }

    public Cliente getClienteEn() {
        return clienteEn;
    }

    public void setClienteEn(Cliente clienteEn) {
        this.clienteEn = clienteEn;
    }

    

    
    

    
    
    
}
