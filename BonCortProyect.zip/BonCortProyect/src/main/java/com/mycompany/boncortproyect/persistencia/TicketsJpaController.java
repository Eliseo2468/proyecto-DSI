/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.boncortproyect.persistencia;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.mycompany.boncortproyect.logica.Cliente;
import com.mycompany.boncortproyect.logica.Tickets;
import com.mycompany.boncortproyect.persistencia.exceptions.NonexistentEntityException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Cesar
 */
public class TicketsJpaController implements Serializable {

    public TicketsJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    public TicketsJpaController() {
        emf=Persistence.createEntityManagerFactory("BonCortPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Tickets tickets) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cliente clienteRe = tickets.getClienteRe();
            if (clienteRe != null) {
                clienteRe = em.getReference(clienteRe.getClass(), clienteRe.getId_cliente());
                tickets.setClienteRe(clienteRe);
            }
            Cliente clienteEn = tickets.getClienteEn();
            if (clienteEn != null) {
                clienteEn = em.getReference(clienteEn.getClass(), clienteEn.getId_cliente());
                tickets.setClienteEn(clienteEn);
            }
            em.persist(tickets);
            if (clienteRe != null) {
                clienteRe.getTiketsRe().add(tickets);
                clienteRe = em.merge(clienteRe);
            }
            if (clienteEn != null) {
                clienteEn.getTiketsRe().add(tickets);
                clienteEn = em.merge(clienteEn);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Tickets tickets) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Tickets persistentTickets = em.find(Tickets.class, tickets.getId_tickets());
            Cliente clienteReOld = persistentTickets.getClienteRe();
            Cliente clienteReNew = tickets.getClienteRe();
            Cliente clienteEnOld = persistentTickets.getClienteEn();
            Cliente clienteEnNew = tickets.getClienteEn();
            if (clienteReNew != null) {
                clienteReNew = em.getReference(clienteReNew.getClass(), clienteReNew.getId_cliente());
                tickets.setClienteRe(clienteReNew);
            }
            if (clienteEnNew != null) {
                clienteEnNew = em.getReference(clienteEnNew.getClass(), clienteEnNew.getId_cliente());
                tickets.setClienteEn(clienteEnNew);
            }
            tickets = em.merge(tickets);
            if (clienteReOld != null && !clienteReOld.equals(clienteReNew)) {
                clienteReOld.getTiketsRe().remove(tickets);
                clienteReOld = em.merge(clienteReOld);
            }
            if (clienteReNew != null && !clienteReNew.equals(clienteReOld)) {
                clienteReNew.getTiketsRe().add(tickets);
                clienteReNew = em.merge(clienteReNew);
            }
            if (clienteEnOld != null && !clienteEnOld.equals(clienteEnNew)) {
                clienteEnOld.getTiketsRe().remove(tickets);
                clienteEnOld = em.merge(clienteEnOld);
            }
            if (clienteEnNew != null && !clienteEnNew.equals(clienteEnOld)) {
                clienteEnNew.getTiketsRe().add(tickets);
                clienteEnNew = em.merge(clienteEnNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                int id = tickets.getId_tickets();
                if (findTickets(id) == null) {
                    throw new NonexistentEntityException("The tickets with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(int id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Tickets tickets;
            try {
                tickets = em.getReference(Tickets.class, id);
                tickets.getId_tickets();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The tickets with id " + id + " no longer exists.", enfe);
            }
            Cliente clienteRe = tickets.getClienteRe();
            if (clienteRe != null) {
                clienteRe.getTiketsRe().remove(tickets);
                clienteRe = em.merge(clienteRe);
            }
            Cliente clienteEn = tickets.getClienteEn();
            if (clienteEn != null) {
                clienteEn.getTiketsRe().remove(tickets);
                clienteEn = em.merge(clienteEn);
            }
            em.remove(tickets);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Tickets> findTicketsEntities() {
        return findTicketsEntities(true, -1, -1);
    }

    public List<Tickets> findTicketsEntities(int maxResults, int firstResult) {
        return findTicketsEntities(false, maxResults, firstResult);
    }

    private List<Tickets> findTicketsEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Tickets.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Tickets findTickets(int id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Tickets.class, id);
        } finally {
            em.close();
        }
    }

    public int getTicketsCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Tickets> rt = cq.from(Tickets.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
