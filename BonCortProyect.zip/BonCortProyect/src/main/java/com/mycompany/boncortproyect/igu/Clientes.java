/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package com.mycompany.boncortproyect.igu;

import com.mycompany.boncortproyect.logica.Cliente;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Roberto Laínez
 */
public class Clientes extends javax.swing.JInternalFrame {
    //sirve para verificar si el usuario quiere guardar cambios


    public Clientes() {
        initComponents();
        //agregando datos a la tabla
        agregarDatos(txtBusqueda.getText());
       
        //agregando listener a la tabla si se toca
        tbClientes.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            
            int filaSelect=tbClientes.getSelectedRow();
            btnEditar.setEnabled(true);
            btnEliminar.setEnabled(true);

        }
        });
        
        //si el usuario preciona enter
        tbClientes.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    
                    int filaSelect = tbClientes.getSelectedRow();
                    modificarDatos(filaSelect);
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {
                
            }
        });
        
    }
    
    //funcion utilizada para crear la tabla y agregar datos de la base de datos en ella
    public void agregarDatos(String busqueda){
        //se le ponen los parametros de cada columna
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Nombre");
        model.addColumn("Direccion");
        model.addColumn("Telefono");
       
        //conexion con la base de datos
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("BonCortPU");
        EntityManager em= emf.createEntityManager();

        Query query = em.createQuery("SELECT c FROM Cliente c");
        List<Cliente> listaClientes = query.getResultList();
        
        //foreach para llenar la tabla con la listaClientes
        for (Cliente cliente : listaClientes) {
            if(busqueda.isEmpty()){
                Object[] row = { cliente.getId_cliente(),cliente.getNombre_Cliente(),cliente.getDireccion_cliente(),cliente.getTelefono_cliente()};
                model.addRow(row);
            }else if(cliente.getNombre_Cliente().equals(busqueda)){
                Object[] row = { cliente.getId_cliente(),cliente.getNombre_Cliente(),cliente.getDireccion_cliente(),cliente.getTelefono_cliente()};
                model.addRow(row);
            }
            
        }
        tbClientes.setModel(model);
        model.fireTableDataChanged();
        
        
    }
    
    //funcion que rehaze la tabla para mostrar cambios en esta
    public void actualizarDatos(){
        DefaultTableModel model = (DefaultTableModel) tbClientes.getModel();
        model.setRowCount(0);
        model.setColumnCount(0);
        agregarDatos(txtBusqueda.getText());
    }
    
    //funcion utilizada para modificar los datos de la tabla tanto de ella misma como de la base de datos
    private void modificarDatos(int filaSelec){
      
        if(filaSelec!=-1){
            //recolectando datos a modificar
        int id_cliente=Integer.parseInt(tbClientes.getValueAt(filaSelec,0).toString());
        String nombre_Cliente=tbClientes.getValueAt(filaSelec, 1).toString();
        String Direccion_cliente=tbClientes.getValueAt(filaSelec, 2).toString();
        String telefono_cliente=tbClientes.getValueAt(filaSelec, 3).toString();
        
        //conexion con la base de datos
        EntityManagerFactory emfE=Persistence.createEntityManagerFactory("BonCortPU");
        EntityManager emE=emfE.createEntityManager();
        
        //retornando el valor a 
        emE.getTransaction().begin();
        Cliente modfCliente=emE.find(Cliente.class, id_cliente);
        //verificar errores
        try{
            
            try{
            //modificando datos
            modfCliente.setNombre_Cliente(nombre_Cliente);
            modfCliente.setDireccion_cliente(Direccion_cliente);
            modfCliente.setTelefono_cliente(telefono_cliente);
            emE.getTransaction().commit(); 
            
            }finally{
                //cerrando conexion con la base de datos
                emE.close();
                emfE.close();
                JOptionPane.showMessageDialog(this, "Cliente actualizado correctamente", "Éxito", JOptionPane.OK_OPTION);
                //se actualizan los datos de la vista
                actualizarDatos();
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Error al actualizar cliente", "Error", JOptionPane.ERROR);
        }
        }
        
    }
    
    //funcion utilizada para eliminar un cliente tanto de la tabla de la vista como en la base de datos
    private void eliminarDatos(int filaSelec){
        //conexion con la base de datos
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("BonCortPU");
        EntityManager em=emf.createEntityManager();
        
        em.getTransaction().begin();
        //retornando id del cliente
        int id_cliente=Integer.parseInt(tbClientes.getValueAt(filaSelec,0).toString());
        
        try{
            //retornando cliente con id
            Cliente cliente=em.find(Cliente.class, id_cliente);
            
            //removiendo cliente
            if (cliente != null) {
            em.remove(cliente);
            em.getTransaction().commit();
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error al Eliminar", "Error", JOptionPane.ERROR);
        }finally{
            em.close();
            emf.close();
            actualizarDatos();
            JOptionPane.showMessageDialog(this, "Cliente Eliminado correctamente", "Éxito", JOptionPane.OK_OPTION);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtBusqueda = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbClientes = new javax.swing.JTable();
        btnEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();

        btnBuscar.setBackground(new java.awt.Color(255, 9, 31));
        btnBuscar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        tbClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tbClientes);

        btnEditar.setBackground(new java.awt.Color(255, 9, 31));
        btnEditar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.setEnabled(false);
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnEliminar.setBackground(new java.awt.Color(255, 9, 31));
        btnEliminar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.setEnabled(false);
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(78, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(68, 68, 68)
                                .addComponent(txtBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(37, 37, 37)
                                .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 883, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(37, 37, 37))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(120, 120, 120)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(268, 268, 268))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEditar, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE))
                .addGap(107, 107, 107))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        //eliminando datos gracias al id
        int filaSelect=tbClientes.getSelectedRow();
        eliminarDatos(filaSelect);
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        //modificando datos gracias al id
        int filaSelect=tbClientes.getSelectedRow();
        modificarDatos(filaSelect);
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        actualizarDatos();
    }//GEN-LAST:event_btnBuscarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbClientes;
    private javax.swing.JTextField txtBusqueda;
    // End of variables declaration//GEN-END:variables
}
