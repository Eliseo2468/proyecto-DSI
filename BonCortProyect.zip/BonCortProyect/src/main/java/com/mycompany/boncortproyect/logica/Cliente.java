/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.boncortproyect.logica;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Cesar
 */
@Entity
@Table(name = "Cliente")
public class Cliente implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id_cliente")
    private int id_cliente;
    @Column(name = "nombre_Cliente")
    private String nombre_Cliente;
    @Column(name = "Direccion_cliente")
    private String Direccion_cliente;
    @Column(name = "telefono_cliente")
    private String telefono_cliente;
    
    @OneToMany(mappedBy = "clienteRe", cascade = CascadeType.ALL)
    private List<Tickets> tiketsRe = new ArrayList<>();

    @OneToMany(mappedBy = "clienteEn", cascade = CascadeType.ALL)
    private List<Tickets> tiketsEn = new ArrayList<>();


    public Cliente() {
    }

    public Cliente(int id_cliente, String nombre_Cliente, String Direccion_cliente, String telefono_cliente) {
        this.id_cliente = id_cliente;
        this.nombre_Cliente = nombre_Cliente;
        this.Direccion_cliente = Direccion_cliente;
        this.telefono_cliente = telefono_cliente;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNombre_Cliente() {
        return nombre_Cliente;
    }

    public void setNombre_Cliente(String nombre_Cliente) {
        this.nombre_Cliente = nombre_Cliente;
    }

    public String getDireccion_cliente() {
        return Direccion_cliente;
    }

    public void setDireccion_cliente(String Direccion_cliente) {
        this.Direccion_cliente = Direccion_cliente;
    }

    public String getTelefono_cliente() {
        return telefono_cliente;
    }

    public void setTelefono_cliente(String telefono_cliente) {
        this.telefono_cliente = telefono_cliente;
    }

    public List<Tickets> getTiketsRe() {
        return tiketsRe;
    }

    public void setTiketsRe(List<Tickets> tiketsRe) {
        this.tiketsRe = tiketsRe;
    }

    public List<Tickets> getTiketsEn() {
        return tiketsEn;
    }

    public void setTiketsEn(List<Tickets> tiketsEn) {
        this.tiketsEn = tiketsEn;
    }

    
    
    
}
