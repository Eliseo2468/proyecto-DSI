/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package com.mycompany.boncortproyect.igu;

import com.mycompany.boncortproyect.logica.Cliente;
import com.mycompany.boncortproyect.logica.Tickets;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Reportes extends javax.swing.JInternalFrame {

    /**
     * Creates new form Reportes
     */
    public Reportes() {
        initComponents();
        //agregando datos a la tabla
        agregarDatos();
        
        //agregando listener a la tabla si se toca
        tbTickets.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            
            int filaSelect=tbTickets.getSelectedRow();
            btnGenerar.setEnabled(false);

        }
        });
        
        //si el usuario preciona enter
        tbTickets.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    
                    int filaSelect = tbTickets.getSelectedRow();
                    modificarDatos(filaSelect);
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {
                
            }
        });
    }

    //funcion utilizada para crear la tabla y agregar datos de la base de datos en ella
    public void agregarDatos(){
        //se le ponen los parametros de cada columna
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Contenido");
        model.addColumn("Numero");
        model.addColumn("Peso");
        model.addColumn("Precio");
        model.addColumn("Envia");
        model.addColumn("Recibe");
        
       
        //conexion con la base de datos
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("BonCortPU");
        EntityManager em= emf.createEntityManager();

        Query query = em.createQuery("SELECT c FROM Tickets c");
        List<Tickets> listaTickets = query.getResultList();
        
        //foreach para llenar la tabla con la listaTickets
        for (Tickets ticket : listaTickets) {
                Object[] row = {ticket.getId_tickets(),ticket.getContenido(),ticket.getNum_vinieta(),ticket.getPeso_paquete(),ticket.getPrecio_paquete(),ticket.getClienteEn().getNombre_Cliente(),ticket.getClienteRe().getNombre_Cliente()};
                model.addRow(row);
        }
        tbTickets.setModel(model);
        model.fireTableDataChanged();
        
        
    }
    
    //funcion para actualizar la tabla
    public void actualizarDatos(){
        DefaultTableModel model = (DefaultTableModel) tbTickets.getModel();
        model.setRowCount(0);
        model.setColumnCount(0);
        agregarDatos();
    }
    
    //funcion utilizada para modificar los datos de la tabla tanto de ella misma como de la base de datos
    private void modificarDatos(int filaSelec){
      
        if(filaSelec!=-1){
            //recolectando datos a modificar
        int id_tickets=Integer.parseInt(tbTickets.getValueAt(filaSelec,0).toString());
        String Contenido=tbTickets.getValueAt(filaSelec, 1).toString();
        String Num_vinieta=tbTickets.getValueAt(filaSelec, 2).toString();
        float peso_paquete=Float.parseFloat(tbTickets.getValueAt(filaSelec, 3).toString());
        float precio_paquete=Float.parseFloat(tbTickets.getValueAt(filaSelec, 4).toString());
        
        
        //conexion con la base de datos
        EntityManagerFactory emfE=Persistence.createEntityManagerFactory("BonCortPU");
        EntityManager emE=emfE.createEntityManager();
        
        //retornando el valor a 
        emE.getTransaction().begin();
            Tickets modfTickets=emE.find(Tickets.class, id_tickets);
        //verificar errores
        try{
            
            try{
            //modificando datos
            modfTickets.setContenido(Contenido);
            modfTickets.setNum_vinieta(Num_vinieta);
            modfTickets.setPeso_paquete(peso_paquete);
            modfTickets.setPrecio_paquete(precio_paquete);
            emE.getTransaction().commit(); 
            
            }finally{
                //cerrando conexion con la base de datos
                emE.close();
                emfE.close();
                JOptionPane.showMessageDialog(this, "Ticket actualizado correctamente", "Éxito", JOptionPane.OK_OPTION);
                //se actualizan los datos de la vista
                actualizarDatos();
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Error al actualizar Ticket", "Error", JOptionPane.ERROR);
        }
        }
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tbTickets = new javax.swing.JTable();
        btnGenerar = new javax.swing.JButton();

        tbTickets.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tbTickets);

        btnGenerar.setBackground(new java.awt.Color(255, 9, 31));
        btnGenerar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnGenerar.setText("Generar Reportes");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(263, 263, 263)
                        .addComponent(btnGenerar, javax.swing.GroupLayout.PREFERRED_SIZE, 559, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 956, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(82, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnGenerar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(113, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGenerar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbTickets;
    // End of variables declaration//GEN-END:variables
}
